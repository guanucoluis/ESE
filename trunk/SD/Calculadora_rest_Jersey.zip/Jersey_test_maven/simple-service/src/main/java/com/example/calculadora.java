package com.example;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("calculadora")
public class calculadora {

	@GET
	@Produces(MediaType.TEXT_HTML)
	public Response welcome (){
		String msg = String.format("SISTEMAS DISTRIBUIDOS: DEMO CALCULADORA REST");
	return Response.status(200).entity(msg).build();	
	}
	  
	@GET
	@Path("/sumar/{val1}/{val2}")
	@Produces(MediaType.TEXT_HTML)
	public Response sumar(@PathParam("val1") double value1, @PathParam("val2") double value2){
		double answer = value1 + value2;
		String msg = String.format("LA SUMA de %10.2f y %10.2f ES %10.2f",value1, value2, answer);
    return Response.status(200).entity(msg).build();
	}
	
	@GET
	@Path("/restar/{val1}/{val2}")
	@Produces(MediaType.TEXT_HTML)
	public Response restar(@PathParam("val1") double value1, @PathParam("val2") double value2){
		double answer = value1 - value2;
		String msg = String.format("LA RESTA DE %10.2f y %10.2f ES %10.2f",value1, value2, answer);
    return Response.status(200).entity(msg).build();
	}
	
	@GET
	@Path("/multiplicar/{val1}/{val2}")
	@Produces(MediaType.TEXT_HTML)
	public Response multiplicar(@PathParam("val1") double value1, @PathParam("val2") double value2){
		double answer = value1 * value2;
		String msg = String.format("LA MULTIPLICACION DE %10.2f y %10.2f ES %10.2f",value1, value2, answer);
    return Response.status(200).entity(msg).build();
	}
	
	@GET
	@Path("/dividir/{val1}/{val2}")
	@Produces(MediaType.TEXT_HTML)
	public Response dividir(@PathParam("val1") double value1, @PathParam("val2") double value2){
		double answer = value1 / value2;
		String msg = String.format("LA DIVISION ENTRE %10.2f y %10.2f ES %10.2f",value1, value2, answer);
    return Response.status(200).entity(msg).build();
	}
}
